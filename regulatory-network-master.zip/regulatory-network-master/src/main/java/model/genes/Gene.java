package model.genes;

public interface Gene extends RegulatoryGene, RegulatedGene{
}
