package model.genes;

import model.regulators.Regulator;

public class ConcreteGene implements Gene{

    private Regulator regulator;
    private double proteinConcentration;
    private final double initialProteinConcentration;
    private final double maximalProduction;
    private final double degradationRate;
    private final String name;
    private boolean isSignaled;

    public ConcreteGene(String name, double maximalProduction, double degradationRate, double initialProteinConcentration,
                        boolean isSignaled){
        this.name= name;
        this.maximalProduction= maximalProduction;
        this.degradationRate=degradationRate;
        this.initialProteinConcentration=initialProteinConcentration;
        proteinConcentration = initialProteinConcentration;
        this.isSignaled= isSignaled;

    }
    @Override
    public double getProteinConcentration() {
        return proteinConcentration;
    }

    @Override
    public double getInitialProteinConcentration() {
        return initialProteinConcentration;
    }

    @Override
    public void setProteinConcentration(double proteinConcentration) {
        this.proteinConcentration=proteinConcentration;
    }

    @Override
    public String getName() {
        return name;
    }
    /**
     * Updates the protein concentration in the ConcreteGene object based on the specified duration.
     *
     * @param duration The duration of the update in time units.
     */
    @Override
    public void update(double duration) {
        //  plus la durée est longue, plus la production et la dégradation ont d'impact sur la concentration de protéine.
        proteinConcentration+=duration*(production()-degradation());
    }

    @Override
    public double getMaximalProduction() {
        return maximalProduction;
    }

    @Override
    public double getDegradationRate() {
        return degradationRate;
    }

    @Override
    public Regulator getRegulator() {
        return regulator;
    }

    @Override
    public void setRegulator(Regulator regulator) {
        this.regulator= regulator;

    }
    public boolean isSignaled(){
        return isSignaled;
    }
    public void setSignaled(boolean isSignaled){
        this.isSignaled = isSignaled;

    }
    private double degradation(){
        return degradationRate * proteinConcentration;
    }
    private double production(){
        // si le regulator est null la production de la proteine est maximale
        if(regulator == null){
            return maximalProduction;
        }
        return regulator.inputFunction()*maximalProduction;
    }

}
