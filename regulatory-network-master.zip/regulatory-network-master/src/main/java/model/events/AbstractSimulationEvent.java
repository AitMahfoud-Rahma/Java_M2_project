package model.events;
import model.genes.Gene;
import model.genes.RegulatoryGene;
import java.util.List;
// je ne suis pas sure d'utiliser gene ou RegulatoryGene
public abstract class AbstractSimulationEvent implements SimulationEvent{
    private final double time;
    private final List<Gene> genes;

    protected AbstractSimulationEvent(List<Gene> genes, double time){
        this.genes = genes;
        this.time = time;
    }
    public void updateGenes(){
        for(Gene gene:genes){
            updateGene(gene);
        }
    }
    public double getTime(){  return time;}
    public List<Gene> getGenes(){return genes;}
    protected abstract void updateGene(Gene gene);

}
