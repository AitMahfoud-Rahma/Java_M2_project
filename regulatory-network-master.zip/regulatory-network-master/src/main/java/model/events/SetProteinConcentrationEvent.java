package model.events;

import model.genes.Gene;

import java.util.List;

public class SetProteinConcentrationEvent extends AbstractSimulationEvent{
    private final double newConcentration;

    public SetProteinConcentrationEvent(List<Gene> genes, double time, double newConcentration){
        super(genes, time);
        this.newConcentration= newConcentration;
    }
    @Override
    protected void updateGene(Gene gene) {
        gene.setProteinConcentration(newConcentration);
    }

    @Override
    public String description() {
        return "The new protein concentration value is : "+ newConcentration;
    }
}
