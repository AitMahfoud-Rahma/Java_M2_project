package model.events;

import model.genes.Gene;

import java.util.List;

public class SetSignaledEvent extends AbstractSimulationEvent{
    private final boolean newSignaledValue;

    public SetSignaledEvent(List<Gene> genes, double time, boolean newSignaledValue) {
        super(genes, time);
        this.newSignaledValue = newSignaledValue;
    }

    @Override
    protected void updateGene(Gene gene) {
        gene.setSignaled(newSignaledValue);
    }
    public String description(){
        return "The new signaled value is : "+ newSignaledValue; };
}
