package model.regulators;

import model.genes.Gene;

public class BooleanActivator extends BooleanRegulator{
    public BooleanActivator(double threshold, Gene gene){
        super(threshold,gene);

    }
    public double inputFunction(){
        if(geneIsSignaled() && thresholdsAttained()){
            return 1.0;
        }
        return 0.0;
    }
}
