package model.regulators;

import model.genes.Gene;

public class BooleanRepressor extends BooleanRegulator{
    public BooleanRepressor(double threshold, Gene gene){
        super(threshold, gene);

    }
    public double inputFunction(){
        if(geneIsSignaled() && thresholdsAttained()){
            return 0.0;
        }
        return 1;
    }

}
