package model.regulators;

import model.genes.Gene;
import model.genes.RegulatedGene;

public abstract class BooleanRegulator implements Regulator{
    protected double threshold;
    protected Gene gene;

    protected BooleanRegulator(double threshold, Gene gene){
        this.threshold=threshold;
        this.gene=gene;
    }
    protected boolean thresholdsAttained(){
        return gene.getProteinConcentration()>=threshold;
    };
    protected boolean geneIsSignaled(){
        return gene.isSignaled();
    };
    public String description(){
        return threshold + " " + gene.getName();
    };
}
