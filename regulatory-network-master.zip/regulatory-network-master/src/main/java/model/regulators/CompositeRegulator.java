package model.regulators;

import java.util.List;

public abstract class CompositeRegulator implements Regulator{
    private final List<Regulator> regulators;

    protected CompositeRegulator(List<Regulator> regulators){
        this.regulators=regulators;
    }
    public double inputFunction(){
        double cumulativeValue = initialValue();
        // Hna il faut que had la fonction utilise les methodes(max et min) f les classes filles et ittérate
        // de la liste des régulators
        for(Regulator regulator:regulators){
        cumulativeValue= cumulativeValue(cumulativeValue,regulator.inputFunction());
        }
        return cumulativeValue;
    }
    protected abstract double initialValue();

    protected abstract double cumulativeValue(double accumulator, double value);

    public String description(){
        StringBuilder myDescription= new StringBuilder();
        for(Regulator regulator: regulators){
            myDescription= myDescription.append(regulator.getClass().getName()).append(",").append(regulator.description()).append("\n");
        }
        return myDescription.toString();
    }
}
