package model.regulators;

import model.genes.Gene;

public class AlwaysOnRegulator implements Regulator {
    @Override
    public double inputFunction() {
        return 1;
    }

    @Override
    public String description() {
        return "";
    }


}
