package model.file.writer;

import model.file.writer.GeneVisitor;
import model.network.RegulatoryNetwork;

import java.io.BufferedWriter;

public class RegulatoryNetworkWriter {
    private GeneVisitor geneVisitor;

    public void RegulatoryNetworkWriter() {
    }

    void write(BufferedWriter bufferedWriter, RegulatoryNetwork
            regulatoryNetwork){}
    private void writeGenes(BufferedWriter bufferedWriter, RegulatoryNetwork regulatoryNetwork){}
    private void writerConfiguration(BufferedWriter bufferedWriter, RegulatoryNetwork regulatoryNetwork){}

}
