package model.file.writer;

public class ConcreteGeneVisitor {
}
