package model.file.writer;

public interface GeneVisitor {
}
