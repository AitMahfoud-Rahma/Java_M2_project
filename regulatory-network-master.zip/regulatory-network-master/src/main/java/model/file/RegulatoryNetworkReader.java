package model.file;

import model.network.RegulatoryNetwork;

import java.io.BufferedReader;

public class RegulatoryNetworkReader {

    RegulatoryNetwork read(BufferedReader bufferedReader){

        return null;
    }
}
