package model.file.gene;

import model.file.RegulatoryNetworkReader;
import model.file.writer.RegulatoryNetworkWriter;
import model.genes.ConcreteGene;

public class ConcreteGeneSerializer {
    private ConcreteGeneSerializer instance;
    private ConcreteGeneSerializer(){

    }
    public String getCode(){
        return "ConcreteGene";
    }
    public String serialize(ConcreteGene event, RegulatoryNetworkWriter writer){
        return "";
    }
    public ConcreteGene deserialize(String string, RegulatoryNetworkReader reader){
        return null;
    }
    public ConcreteGeneSerializer getInstance(){
        return instance;
    }
}
