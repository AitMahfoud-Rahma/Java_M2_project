package model.file.gene;

import model.file.RegulatoryNetworkReader;
import model.file.writer.RegulatoryNetworkWriter;
import model.genes.ConstantGene;

public class ConstantGeneSerializer {
    private ConstantGeneSerializer instance;
    private ConstantGeneSerializer(){};
    public String getCode(){
        return "ConsatntGene";
    }
    public String serialize(ConstantGene event, RegulatoryNetworkWriter writer){
        return "";
    }
    public ConstantGene deserialize(String string, RegulatoryNetworkReader reader){
        return null;
    }
    public ConstantGeneSerializer getInstance(){
        return instance;}
}
