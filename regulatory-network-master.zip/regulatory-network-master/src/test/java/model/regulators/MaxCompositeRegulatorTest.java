package model.regulators;

import model.genes.ConcreteGene;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.*;
import java.util.ArrayList;
import java.util.List;

public class MaxCompositeRegulatorTest {
    private CompositeRegulator compositeRegulator;
    private MaxCompositeRegulator maxCompositeRegulator;
    private ConcreteGene geneX;
    private ConcreteGene geneY;
    private ConcreteGene geneZ;
    @BeforeEach
    void initialize(){
        List<Regulator> regulators = new ArrayList<>();
        BooleanActivator activator = new BooleanActivator(2, geneX);
        BooleanRepressor repressor= new BooleanRepressor(1,geneY);
        regulators.add(activator);
        regulators.add(repressor);
        maxCompositeRegulator= new MaxCompositeRegulator(regulators);
    }
    @Test
    void initialValueTest(){
        assertThat(maxCompositeRegulator.initialValue()).isEqualTo(0.0);
    }
    @Test
    void cumulativeValueTest(){
        double accumulator= 3.0;
        double value= 2.1;
        assertThat(maxCompositeRegulator.cumulativeValue(accumulator,value)).isEqualTo(3.0);
    }
    

}
