package model.regulators;

import model.genes.ConcreteGene;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class BooleanRepressorTest {
    private double threshold;
    private ConcreteGene geneX;
    private ConcreteGene geneY;
    private ConcreteGene geneZ;
    private BooleanRepressor booleanRepressorX;
    private BooleanRepressor booleanRepressorY;
    private BooleanRepressor booleanRepressorZ;

    @BeforeEach
    void initialize(){
        threshold= 25;
        geneX = new ConcreteGene("X", 100.0,0.2,50.0,true);
        geneY = new ConcreteGene("Y", 50.0,0.5,20.0,true);
        geneZ = new ConcreteGene("Z", 60.0,0.7,10.0,false);
        booleanRepressorX = new BooleanRepressor(threshold, geneX);
        booleanRepressorY = new BooleanRepressor(threshold, geneY);
        booleanRepressorZ = new BooleanRepressor(threshold, geneZ);
    }
    @Test
    void thresholdAttainedTest(){
        assertThat(booleanRepressorX.thresholdsAttained()).isTrue();
        assertThat(booleanRepressorY.thresholdsAttained()).isFalse();
        assertThat(booleanRepressorZ.thresholdsAttained()).isFalse();
    }
    @Test
    void isSignaledTest(){
        assertThat(booleanRepressorX.geneIsSignaled()).isTrue();
        assertThat(booleanRepressorY.geneIsSignaled()).isTrue();
        assertThat(booleanRepressorZ.geneIsSignaled()).isFalse();
    }

    @Test
    void inputFunctionTest(){
        assertThat(booleanRepressorX.inputFunction()).isEqualTo(0.0);
        assertThat(booleanRepressorY.inputFunction()).isEqualTo(1.0);
        assertThat(booleanRepressorZ.inputFunction()).isEqualTo(1.0);

    }

}
