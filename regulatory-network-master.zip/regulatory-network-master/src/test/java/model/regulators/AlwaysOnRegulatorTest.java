package model.regulators;
import static org.assertj.core.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AlwaysOnRegulatorTest {
    private AlwaysOnRegulator regulator1;
    private AlwaysOnRegulator regulator2;
    private AlwaysOnRegulator regulator3;
    @BeforeEach
    void initializeGenes(){
        regulator1 = new AlwaysOnRegulator();
        regulator2 = new AlwaysOnRegulator();
        regulator3 = new AlwaysOnRegulator();
    }

    @Test
    void inputFunctionTest(){
        assertThat(regulator1.inputFunction()).isEqualTo(1);
        assertThat(regulator2.inputFunction()).isEqualTo(1);
        assertThat(regulator3.inputFunction()).isEqualTo(1);
    }
    @Test
    void descriptionTest(){
        assertThat(regulator1.description()).isSameAs("");
        assertThat(regulator2.description()).isSameAs("");
        assertThat(regulator3.description()).isSameAs("");
    }
}
