package model.regulators;
import static org.assertj.core.api.Assertions.*;
import model.genes.ConcreteGene;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class BooleanActivatorTest {
    public ConcreteGene geneX;
    public ConcreteGene geneY;
    public ConcreteGene geneZ;
    public BooleanActivator booleanActivatorX;
    public BooleanActivator booleanActivatorY;
    public BooleanActivator booleanActivatorZ;

    @BeforeEach
    void initialize(){
        double threshold = 25;
        geneX = new ConcreteGene("X", 100.0,0.2,50.0,true);
        geneY = new ConcreteGene("Y", 50.0,0.5,20.0,true);
        geneZ = new ConcreteGene("Z", 60.0,0.7,10.0,false);
        booleanActivatorX = new BooleanActivator(threshold, geneX);
        booleanActivatorY = new BooleanActivator(threshold, geneY);
        booleanActivatorZ = new BooleanActivator(threshold, geneZ);
    }


    @Test
    void thresholdAttainedTest(){
        assertThat(booleanActivatorX.thresholdsAttained()).isTrue();
        assertThat(booleanActivatorY.thresholdsAttained()).isFalse();
        assertThat(booleanActivatorZ.thresholdsAttained()).isFalse();
    }
    @Test
    void isSignaledTest(){
        assertThat(booleanActivatorX.geneIsSignaled()).isTrue();
        assertThat(booleanActivatorY.geneIsSignaled()).isTrue();
        assertThat(booleanActivatorZ.geneIsSignaled()).isFalse();
    }

    @Test
    void inputFunctionTest(){
        assertThat(booleanActivatorX.inputFunction()).isEqualTo(1.0);
        assertThat(booleanActivatorY.inputFunction()).isEqualTo(0.0);
        assertThat(booleanActivatorZ.inputFunction()).isEqualTo(0.0);
    }




}
