package model.genes;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.*;
public class ConcreteGeneTest {
    private ConcreteGene geneX;
    private ConcreteGene geneY;
    private ConcreteGene geneZ;
    @BeforeEach
    void initialize() {
        geneX = new ConcreteGene("X", 120.0, 0.3, 20.0, true);
        geneY = new ConcreteGene("Y", 100.0, 0.1, 50.0, true);
        geneZ = new ConcreteGene("Z", 50.0, 0.2, 30.0, true);
    }
    @Test
    void testGetInitialProteinConcentration(){
        assertThat(geneX.getInitialProteinConcentration()).isEqualTo(20.0);
        assertThat(geneY.getInitialProteinConcentration()).isEqualTo(50.0);
        assertThat(geneZ.getInitialProteinConcentration()).isEqualTo(30.0);
    }
    @Test
    void testGetName(){
        assertThat(geneX.getName()).isSameAs("X");
        assertThat(geneY.getName()).isSameAs("Y");
        assertThat(geneZ.getName()).isSameAs("Z");
    }
    @Test
    void testSetProteinConcentration(){
        geneX.setProteinConcentration(30.0);
        assertThat(geneX.getProteinConcentration()).isEqualTo(30.0);
        geneY.setProteinConcentration(15.0);
        assertThat(geneY.getProteinConcentration()).isEqualTo(15.0);
    }
    @Test
    void testGetMaximalProduction(){
        assertThat(geneX.getMaximalProduction()).isEqualTo(120.0);
        assertThat(geneY.getMaximalProduction()).isEqualTo(100.0);
        assertThat(geneZ.getMaximalProduction()).isEqualTo(50.0);
    }
    @Test
    public void testUpdate(){
        //Update(){return this.proteinConcentration+=duration*(production()-degradation())}
        geneX.update(0.1);
        assertThat(geneX.getProteinConcentration()).isEqualTo(geneX.getInitialProteinConcentration()+0.1*(geneX.getMaximalProduction()- geneX.getInitialProteinConcentration()*geneX.getDegradationRate()));
        geneY.update(1.8);
        assertThat(geneY.getProteinConcentration()).isEqualTo(geneY.getInitialProteinConcentration()+1.8*(geneY.getMaximalProduction()- geneY.getInitialProteinConcentration()*geneY.getDegradationRate()));
        geneZ.update(2);
        assertThat(geneZ.getProteinConcentration()).isEqualTo(geneZ.getInitialProteinConcentration()+2*(geneZ.getMaximalProduction()- geneZ.getInitialProteinConcentration()*geneZ.getDegradationRate()));

    }

    @Test
    void testGetDegradationRate(){
        assertThat(geneX.getDegradationRate()).isEqualTo(0.3);
        assertThat(geneY.getDegradationRate()).isEqualTo(0.1);
        assertThat(geneZ.getDegradationRate()).isEqualTo(0.2);
    }
    @Test
    void testIsSignaled(){
        assertThat(geneX.isSignaled()).isTrue();
        assertThat(geneY.isSignaled()).isTrue();
        assertThat(geneZ.isSignaled()).isTrue();
    }
}
