package model.events;

import model.genes.ConcreteGene;
import model.genes.Gene;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class SetProteinConcentrationEventTest {
    private final List<Gene> genes = new ArrayList<>();
    private Gene geneX;
    private Gene geneY;
    private Gene geneZ;
    private SetProteinConcentrationEvent event;
    private double time;
    private double newConcentration;

    @BeforeEach
    void initialize() {
        geneX = new ConcreteGene("X", 100.0, 0.2, 50.0, true);
        geneY = new ConcreteGene("Y", 50.0, 0.5, 20.0, true);
        geneZ = new ConcreteGene("Z", 60.0, 0.7, 10.0, false);
        genes.add(geneX);
        genes.add(geneY);
        time= 2;
        newConcentration= 75;
        event =new SetProteinConcentrationEvent(genes,time, 75);
    }
    @Test
    void updateGeneTest(){
        event.updateGenes();
        assertThat(geneX.getProteinConcentration()).isEqualTo(newConcentration);
        assertThat(geneY.getProteinConcentration()).isEqualTo(newConcentration);
        assertThat(geneZ.getProteinConcentration()).isNotEqualTo(newConcentration);
    }

    @Test
    void descriptionTest(){
        assertThat(event.description().equals("The new protein concentration value is : "+ newConcentration));
    }

}
