package model.events;
import model.genes.ConcreteGene;
import model.genes.Gene;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class SetSignaledEventTest {
    private final List<Gene> genes = new ArrayList<>();
    private Gene geneX;
    private Gene geneY;
    private Gene geneZ;
    private SetSignaledEvent event;
    private double time;
    private boolean newSignaledValue;
    @BeforeEach
    void initialize() {
        geneX = new ConcreteGene("X", 100.0, 0.2, 50.0, true);
        geneY = new ConcreteGene("Y", 50.0, 0.5, 20.0, true);
        geneZ = new ConcreteGene("Z", 60.0, 0.7, 10.0, false);
        genes.add(geneX);
        genes.add(geneY);
        genes.add(geneZ);
        time= 2;
        newSignaledValue = false;
        event =new SetSignaledEvent(genes,time, false);
    }
    @Test
    void updateGeneTest(){
        event.updateGenes();
        assertThat(geneX.isSignaled()).isEqualTo(newSignaledValue);
        assertThat(geneY.isSignaled()).isEqualTo(newSignaledValue);
}

    @Test
    void descriptionTest(){
        assertThat(event.description().equals("The new signaled value is : "+ newSignaledValue));
    }
}
