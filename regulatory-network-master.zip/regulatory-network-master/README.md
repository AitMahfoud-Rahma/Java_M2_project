# Réseau de régulation de gènes

## Description du projet

Pour ce projet, vous allez implémenter des classes pour simuler un réseau régulation de gènes.

## Membre du projet

- AIT MAHFOUD, Rahma